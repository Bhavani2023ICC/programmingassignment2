﻿using System.Numerics;

namespace StarwarsAssignment.Models
{
    public class Character
    {
        public string Name { get; set; }
        public string Height { get; set; }
        public string Mass { get; set; }
        public string Hair_Color { get; set; }
        public string Skin_Color { get; set; }
        public string Eye_Color { get; set; }
        public string Birth_Year { get; set; }
        public string Gender { get; set; }
        public string Homeworld { get; set; }
        public string Species { get; set; }
        public Species? SpeciesNode { get; set; }
        public Planet? planetsNode { get; set; }

    }
    public class CharacterUpdateModel
    {
        public string Name { get; set; }
        public string Height { get; set; }
        public string Hair_Color { get; set; }
        public string Birth_Year { get; set; }
    }

    public class Neo4jDatabaseSettings
    {
        public string NEO4J_URI { get; set; } = null!;
        public string NEO4J_USER { get; set; } = null!;
        public string NEO4J_PASSWORD { get; set; } = null!;
    }
    public class Planet
    {
        public string Name { get; set; }
        public string Rotation_Period { get; set; }
        public string Orbital_Period { get; set; }
        public string Diameter { get; set; }
        public string Climate { get; set; }
        public string Gravity { get; set; }
        public string Terrain { get; set; }
        public string Surface_Water { get; set; }
        public string Population { get; set; }
    }
    public class Species
    {
        public string Name { get; set; }
        public string Classification { get; set; }
        public string Designation { get; set; }
        public string Average_Height { get; set; }
        public string Skin_Colors { get; set; }
        public string Hair_Colors { get; set; }
        public string Eye_Colors { get; set; }
        public string Average_Lifespan { get; set; }
        public string Language { get; set; }
        public string Homeworld { get; set; }

        public Planet? PlanetsNode { get; set; }
    }
}

