﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using StarwarsAssignment.Models;

namespace StarwarsAssignment.Controllers
{
    [ApiController]
    [Route("/chars")]
    public class StarWarsController : ControllerBase
    {
        private readonly StarWarsService _starWarsService;
        public StarWarsController(StarWarsService starWarsService)
        {
            _starWarsService = starWarsService;
        }

        [HttpGet]
        public async Task<List<Character>> Get()
        {
            return await _starWarsService.GetAsync();
        }

        [HttpGet("{name}")]
        public async Task<ActionResult<Character>> Get(string name)
        {
            var character = await _starWarsService.GetAsync(name);

            if (character is null)
                return NotFound();
            return character;
        }

        [HttpPost]
        public async Task<IActionResult> Post(Character character)
        {
            if (character.Name == null)
                return BadRequest();

            await _starWarsService.CreateAsync(character);

            var chracterObj = await _starWarsService.GetAsync(character.Name);

            return Ok(chracterObj);
        }

        [HttpPatch("{name}")]
        public async Task<IActionResult> Update(string name, CharacterUpdateModel characterModel)
        {
            var characterObj = await _starWarsService.GetAsync(name);

            if (characterObj == null)
                return NotFound();

            var movieUpdated = await _starWarsService.UpdateAsync(name, characterModel);

            return Ok(movieUpdated);
        }

        [HttpDelete("{name}")]
        public async Task<IActionResult> Delete(string name)
        {
            var movie = await _starWarsService.GetAsync(name);

            if (movie == null)
                return NotFound();

            await _starWarsService.RemoveAsync(name);

            return Ok(movie);
        }
    }
}
