﻿using Neo4j.Driver;
using Newtonsoft.Json;
using StarwarsAssignment.Models;

namespace StarwarsAssignment
{
    public class StarWarsService
    {
        private readonly IDriver _driver;
        public StarWarsService(IDriver driver)
        {
            _driver = driver;
        }

        public async Task<List<Character>> GetAsync()
        {
            var session = _driver.AsyncSession(WithDatabase);
            try
            {
                return await session.ReadTransactionAsync(async transaction =>
                {
                    var cursor = await transaction.RunAsync(@"
                        MATCH (c:Characters)
                        OPTIONAL MATCH (c)-[:FROM]->(p:Planets)
                        OPTIONAL MATCH (c)-[:IDENTIFIES_AS]->(s:Species)
                        RETURN DISTINCT c{CharacterNode:c,SpeciesNode:s,PlanetNode:p}"
                    );
                    List<Character> characters = new List<Character>();
                    await cursor.ForEachAsync(result =>
                    {
                        var record = result["c"].As<Dictionary<string, object>>();

                        if (record.ContainsKey("CharacterNode"))
                        {
                            Character character = null;
                            var c = record["CharacterNode"].As<INode>().Properties;
                            character = JsonConvert.DeserializeObject<Character>(JsonConvert.SerializeObject(c));

                            if (record.ContainsKey("SpeciesNode") && record["SpeciesNode"] != null)
                            {
                                var s = record["SpeciesNode"].As<INode>().Properties;
                                character.SpeciesNode = JsonConvert.DeserializeObject<Species>(JsonConvert.SerializeObject(s));
                            }

                            if (record.ContainsKey("PlanetNode") && record["PlanetNode"] != null)
                            {
                                var p = record["PlanetNode"].As<INode>().Properties;
                                character.planetsNode = JsonConvert.DeserializeObject<Planet>(JsonConvert.SerializeObject(p));
                            }
                            characters.Add(character);
                        }

                    });
                    return characters;
                });
            }
            finally
            {
                await session.CloseAsync();
            }
        }

        public async Task<Character?> GetAsync(string name)
        {
            var session = _driver.AsyncSession(WithDatabase);
            try
            {
                return await session.ReadTransactionAsync(async transaction =>
                {
                    Character character = null;

                    var cursor = await transaction.RunAsync(@"
                        MATCH (c:Characters{name:$name})
                        OPTIONAL MATCH (c)-[:FROM]->(p:Planets)
                        OPTIONAL MATCH (c)-[:IDENTIFIES_AS]->(s:Species)
                        RETURN DISTINCT c{CharacterNode:c,SpeciesNode:s,PlanetNode:p}", new { name }
                    );
                    var results = cursor.ToListAsync().Result;
                    if (results.Count == 0)
                    {
                        return null;
                    }
                    //List<Character> characters = new List<Character>();

                    var record = (results[0])["c"].As<Dictionary<string, object>>();

                    if (record.ContainsKey("CharacterNode"))
                    {
                        var c = record["CharacterNode"].As<INode>().Properties;
                        character = JsonConvert.DeserializeObject<Character>(JsonConvert.SerializeObject(c));

                        if (record.ContainsKey("SpeciesNode") && record["SpeciesNode"] != null)
                        {
                            var s = record["SpeciesNode"].As<INode>().Properties;
                            character.SpeciesNode = JsonConvert.DeserializeObject<Species>(JsonConvert.SerializeObject(s));
                        }

                        if (record.ContainsKey("PlanetNode") && record["PlanetNode"] != null)
                        {
                            var p = record["PlanetNode"].As<INode>().Properties;
                            character.planetsNode = JsonConvert.DeserializeObject<Planet>(JsonConvert.SerializeObject(p));
                        }
                    }
                    return character;
                });
            }
            finally
            {
                await session.CloseAsync();
            }
        }
        public async Task CreateAsync(Character character)
        {
            var session = _driver.AsyncSession(WithDatabase);
            try
            {
                await session.WriteTransactionAsync(async transaction =>
                {
                    var cursor = await transaction.RunAsync(@"
                        CREATE (c:Characters{name:$name,height:$height,mass:$mass,hair_color:$hair_color,skin_color:$skin_color,eye_color:$eye_color,birth_year:$birth_year,gender:$gender})
                        MERGE (p:Planets{name:$homeworld})
                        MERGE (c)-[:FROM]->(p)
                        MERGE (s:Species{name:$species})
                        MERGE (c)-[:IDENTIFIES_AS]->(s)
                        ",
                        new
                        {
                            name = character.Name,
                            height = character.Height,
                            mass = character.Mass,
                            hair_color = character.Hair_Color,
                            skin_color = character.Skin_Color,
                            eye_color = character.Eye_Color,
                            birth_year = character.Birth_Year,
                            gender = character.Gender,
                            homeworld = character.Homeworld,
                            species = character.Species
                        }
                    );
                });
            }
            finally
            {
                await session.CloseAsync();
            }
        }


        public async Task<Character?> UpdateAsync(string name, CharacterUpdateModel updateModel)
        {
            var session = _driver.AsyncSession(WithDatabase);
            try
            {
                await session.WriteTransactionAsync(async transaction =>
                {
                    var height = updateModel.Height;
                    var hair_color = updateModel.Hair_Color;
                    var birth_year = updateModel.Birth_Year;
                    var newName = updateModel.Name;
                    var cursor = await transaction.RunAsync(@"
                        MATCH(c: Characters{ name: $name }) SET c.name = $newName,c.hair_color = $hair_color,c.birth_year = $birth_year,c.height = $height",
                         new { name, newName, height, hair_color, birth_year }
                     );
                });

                return await GetAsync(updateModel.Name);
            }
            finally
            {
                await session.CloseAsync();
            }
        }


        public async Task RemoveAsync(string name)
        {
            var session = _driver.AsyncSession(WithDatabase);
            try
            {
                await session.WriteTransactionAsync(async transaction =>
                {
                    var cursor = await transaction.RunAsync(@"
                        MATCH(c:Characters{ name: $name }) DETACH DELETE c",
                         new { name }
                     );
                });

            }
            finally
            {
                await session.CloseAsync();
            }
        }

        private static void WithDatabase(SessionConfigBuilder sessionConfigBuilder)
        {
            var neo4jVersion = Environment.GetEnvironmentVariable("NEO4J_VERSION") ?? "";
            if (!neo4jVersion.StartsWith("5"))
            {
                return;
            }

            sessionConfigBuilder.WithDatabase(Database());
        }

        private static string Database()
        {
            return Environment.GetEnvironmentVariable("NEO4J_DATABASE") ?? "neo4j";
        }
    }
}
