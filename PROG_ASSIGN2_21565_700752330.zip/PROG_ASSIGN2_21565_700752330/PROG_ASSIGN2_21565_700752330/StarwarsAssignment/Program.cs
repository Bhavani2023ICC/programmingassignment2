
using Neo4j.Driver;
using StarwarsAssignment.Models;

namespace StarwarsAssignment
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // Add services to the container.
            builder.Services.Configure<Neo4jDatabaseSettings>(
            builder.Configuration.GetSection("DatabaseSettings"));

            var configuration = builder.Configuration;
            var uri = configuration["DatabaseSettings:NEO4J_URI"];
            var user = configuration["DatabaseSettings:NEO4J_USER"];
            var password = configuration["DatabaseSettings:NEO4J_PASSWORD"];

            builder.Services.AddSingleton<StarWarsService>();
            builder.Services.AddSingleton(GraphDatabase.Driver(uri, AuthTokens.Basic(user, password)));
            builder.Services.AddControllers();
            // Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
            builder.Services.AddEndpointsApiExplorer();
            builder.Services.AddSwaggerGen();

            var app = builder.Build();

            // Configure the HTTP request pipeline.
            if (app.Environment.IsDevelopment())
            {
                app.UseSwagger();
                app.UseSwaggerUI();
            }

            app.UseHttpsRedirection();

            app.UseAuthorization();


            app.MapControllers();

            app.Run();
        }

    }
}
